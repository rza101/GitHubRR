package com.rhezarijaya.githubrr.utils;

public class Constants {
    // INTENT KEYS
    public static final String INTENT_MAIN_DETAIL = "INTENT_MAIN_DETAIL";
}
